# zhDaily
## 申明
* 本插件是基于知乎日报接口制作完成
* 感谢izzyleung提供的知乎日报接口
* 如有侵权，本人会立即下架扩展应用

##地址
* https://chrome.google.com/webstore/detail/%E7%9F%A5%E4%B9%8E%E6%97%A5%E6%8A%A5web%E7%89%88/hgenmoheeaicmomkkkkkoeeihmdpacio

## 更新日志
* v1.0.0 发布
* v1.0.1 更新了扩展官网
* v1.0.2 展示细节优化
* v1.0.3 支持Enter搜索
* v1.1.0 增加选项页，可以自定义日报内容
* v1.1.1 修复主题日报错误，优化tab页